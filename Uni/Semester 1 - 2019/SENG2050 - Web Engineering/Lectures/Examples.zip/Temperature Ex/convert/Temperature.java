/* convert.Temperature */
/* A Java Bean to convert between temperature scales */
/* A temperature < 0.0K is concidered as invalid */

package convert;

public class Temperature
{

/* Remember the temperature in Kelvin */
  private double kelvin;
  public void setKelvin(double kelvin) { this.kelvin = kelvin; }
  public void setKelvin(String kelvin) throws NumberFormatException { setKelvin(new Double(kelvin).doubleValue()); }
  public double getKelvin() { return this.kelvin; }

/* The default value - should be invalid */
  private double defaultKelvin = -1.0;
  public double getDefaultKelvin() { return this.defaultKelvin; }
  public void setToDefault(boolean flag) { if (flag) { setKelvin(getDefaultKelvin()); } }

/* Default constructor */
  public Temperature() { setToDefault(true); }

/* Is the remembered temperature valid */
  public boolean isValid() { return ( getKelvin() >= 0.0 ); }

/* Convert between Kelvin and Celcius */
  public void setCelcius(double celcius) { setKelvin(celcius+273.16); }
  public void setCelcius(String celcius) throws NumberFormatException { setCelcius(new Double(celcius).doubleValue()); }
  public double getCelcius() { return getKelvin()-273.16; }

/* Convert between Kelvin and Farenheit */
  public void setFarenheit(double farenheit) { setCelcius((farenheit-32.0)/1.8); }
  public void setFarenheit(String farenheit) throws NumberFormatException { setFarenheit(new Double(farenheit).doubleValue()); }
  public double getFarenheit() { return (getCelcius()*1.8)+32.0; }

}
