To run the program (for Windows):
	Open a shell in the Assignment3 directory (Windows PowerShell is good here)
	Type javac Assignment3.java
	Type java Assignment3