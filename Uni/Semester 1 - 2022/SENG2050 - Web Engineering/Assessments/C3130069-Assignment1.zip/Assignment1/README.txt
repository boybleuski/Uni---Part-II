To run this servlet:
	- Put this folder into the "Tomcat/webapps" directory.
	- If using Windows, open a Windows PowerShell in the "Tomcat/bin" directory.
	- Execute "./catalina.bat run".
	- In Chrome/Edge, enter "localhost:8080/Assignment1/ForumPage".

Ensure the enviroment variables are as follows:
	CLASSPATH - <Tomcat version 9>\lib\servlet-api.jar;
	JAVA_HOME - <JDK version 11>