package pkg;

import java.io.*;
import java.util.*;

public class CartBean implements Serializable {
    
    private List<CartItemBean> items = new LinkedList<>();
    
    public CartBean() {
        items.add(new CartItemBean("bananas", 1));
        items.add(new CartItemBean("apples", 2));
        items.add(new CartItemBean("museli bars", 1));
        items.add(new CartItemBean("salad", 3));
    }

    public List<CartItemBean> getItems() {
        return items;
    }
}