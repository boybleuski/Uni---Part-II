package pkg;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

import java.util.*;

@WebServlet(urlPatterns = {"/additem"})
public class AddItemServlet extends HttpServlet {

    public void doGet(
        HttpServletRequest request, 
        HttpServletResponse response
    ) throws IOException, ServletException {
        // Setup for view - get valid items
        String[] itemNames = ProductService.getItemNames();
        request.setAttribute("itemNames", itemNames);

        // Pass items to view
        RequestDispatcher dispatcher = this.getServletContext()
            .getRequestDispatcher("/WEB-INF/additem.jsp");
        dispatcher.forward(request, response);
    }

    public void doPost(
        HttpServletRequest request, 
        HttpServletResponse response
    ) throws IOException, ServletException {
        List<String> errors = new ArrayList<>();

        // Get parameters
        String name = request.getParameter("name");
        String qtyStr = request.getParameter("qty");

        // Validate name
        if (name == null) {
            errors.add("No name passed");
        } else if (!ProductService.isValidName(name)) {
            errors.add("Item name is not a valid product name");
        }

        // Validate qty
        int qty = 0;
        try {
            qty = Integer.parseInt(qtyStr);

            if (qty <= 0) {
                errors.add("Qty is less than zero");
            }
        } catch (NumberFormatException ex) {
            errors.add("Qty is not a number");
        }

        // Show an error page if an error was gound
        if (!errors.isEmpty()) {
            // Pass errors to the view
            request.setAttribute("errors", errors);
            
            // Forward on to the error page
            RequestDispatcher dispatcher = this.getServletContext()
                .getRequestDispatcher("/WEB-INF/additem-error.jsp");
            dispatcher.forward(request, response);
            return;
        }

        // Get the current users cart
        HttpSession session = request.getSession();
        CartBean cart = (CartBean) session.getAttribute("cart");
        if (cart == null) {
            cart = new CartBean();
            session.getAttribute("cart");
        }

        // Add the item, and redirect to success page
        cart.getItems().add(new CartItemBean(name, qty));
        response.sendRedirect("/week4example/additems?success=true");
    }
}