package pkg;

import java.util.Arrays;

public class ProductService {
    private static String[] itemNames = {
        "bananas",
        "apples",
        "museli bars",
        "salad",
        "juice"
    };

    public static String[] getItemNames() {
        return itemNames;
    }

    public static boolean isValidName(String name) {
        return Arrays.binarySearch(itemNames, name) >= 0;
    }
}


