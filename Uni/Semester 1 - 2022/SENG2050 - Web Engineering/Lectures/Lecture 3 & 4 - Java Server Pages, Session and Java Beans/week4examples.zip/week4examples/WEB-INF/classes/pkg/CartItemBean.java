package pkg;

import java.io.*;

public class CartItemBean implements Serializable {
        private String name;
        private int qty;

        public CartItemBean() {}
        public CartItemBean(String name, int qty) {
            this.name = name;
            this.qty = qty;
        }

        public String getName() {
            return name;
        }

        public int getQty() {
            return qty;
        }
    }