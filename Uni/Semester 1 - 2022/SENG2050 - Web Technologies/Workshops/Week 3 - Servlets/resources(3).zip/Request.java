	String value = request.getparameter("parameterName");
	if(value==null){
		//the parameter wasn't passed
	}else if(parameter.equals("someValue"){
		//the parameter was an expected value
	}else{	
		//some other value was found
	}
